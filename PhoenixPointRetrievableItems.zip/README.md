# Phoenix-Point-Retrievable-Items
Makes it so enemies always drop their items if they're not destroyed. Note that you'll still need to manually retrieve items when you're defending a faction's haven
or if you're evacuating from a mission.

Requires the Phoenix Point Mod Injector: https://github.com/RealityMachina/PhoenixPointModInjector
# Installation

Place the .dll file inside your PhoenixPoint/Mods folder.

Enjoy.
